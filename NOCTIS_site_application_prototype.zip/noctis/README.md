# NOCTIS — prototype boutique + studio vidéo IA

## Ce qui fonctionne déjà
- Site responsive pour téléphone et ordinateur.
- Catalogue de 3 produits fictifs avec prix modifiables.
- Panier de démonstration qui calcule le total (sans paiement).
- Studio qui génère un prompt vidéo IA personnalisable et permet de le copier.
- Manifest + service worker pour proposer une installation comme application web (PWA) lorsque le site est hébergé en HTTPS.

## Ce qui n'est pas encore connecté
- Paiement réel, livraison, taxes, gestion des stocks et commandes.
- Génération vidéo IA réelle : le studio écrit un prompt, mais ne lance pas un moteur vidéo.
- Compte client, base de données, administration et sauvegarde du panier.
- Les images de vêtements sont des illustrations CSS temporaires, pas des photos de produits.

## Tester
Ouvre `index.html` dans un navigateur pour tester la boutique et le générateur de prompts. Pour installer la PWA et tester le service worker, héberge le dossier en HTTPS.

## Mise en ligne simple (GitHub Pages)
1. Crée un compte GitHub et un nouveau dépôt public nommé `noctis`.
2. Téléverse les 4 fichiers (`index.html`, `manifest.webmanifest`, `sw.js`, `icon.svg`) et ce README.
3. Dans le dépôt : **Settings → Pages**.
4. Choisis **Deploy from a branch**, puis `main` et `/ (root)`, et enregistre.
5. GitHub affichera l'adresse publique du site. Ouvre-la sur ton téléphone.
6. Sur Android/Chrome : menu ⋮ → **Installer l'application** ou **Ajouter à l'écran d'accueil** (le libellé peut varier).

Alternative : Netlify Drop permet généralement de publier un dossier de site statique en le déposant dans son interface.

## Pour accepter des commandes réelles
Pour un premier lancement, utilise une plateforme e-commerce comme Shopify ou une solution de boutique qui gère les paiements, les taxes, les livraisons et les retours. Ne collecte pas les numéros de carte bancaire directement dans ce prototype.

## Pour générer des vidéos réellement
Choisis un service vidéo IA avec une API et des conditions d'usage commercial qui te conviennent. Il faudra un backend sécurisé pour garder la clé API (ne la mets jamais dans le code visible du site), puis connecter le bouton de génération à ce backend.

## Avant de publier
- Remplace les prix, descriptions et illustrations par tes vrais produits.
- Ajoute les pages Contact, Livraison, Retours, Confidentialité et Conditions.
- Vérifie les obligations applicables au Canada/Québec et demande à un adulte de confiance de t'aider pour les comptes de paiement et contrats si tu es mineur.
